import time
import math
import rtde_io
import rtde_receive
import rtde_control
import keyboard
from math import pi

# Import core module:
from coreModule import *
# Import modular code from Pick-and-Place file
from pickAndPlace import *

pressure = 65

hex_string = hex(struct.unpack('<I', struct.pack('<f', pressure))[0])
while len(hex_string) < 2+8: #The hexcode should be length 2+8 ex: 0x00000000. Padd with zeroes as needed
    hex_string += '0'
part1 = hex_string[2:6]
part2 = hex_string[6:10]
#client.write_registers(1009, [int(part1, 16),int(part2, 16)])
client.write_registers(1009, [int(part1, 16),int(part2, 16)])

rtde_io.setStandardDigitalOut(ink_IO, True)

rtde_io.setStandardDigitalOut(ink_IO, False)